export function AccountSettingsController(appApi, UserAccounts, $location, $mdDialog ,$stateParams, $mdToast, $state) {
  console.log($stateParams.integration_id)
  var $ctrl = this;
	$ctrl.api_key;
	$ctrl.team_url;
    $ctrl.userAccounts = UserAccounts;
    $ctrl.integration_id = $stateParams.integration_id
    $ctrl.submitForm = function(){
        $ctrl.isDisabled = true;
		AppApi.submitForm({
//
		                        'AWS_APIAccessKey': $ctrl.accountDetails.api_key,
                                'AWS_APISecretAccess': $ctrl.accountDetails.team_url,
                                'integration_id': $ctrl.integration_id,
									})
									.then(function(response){
									if(response.status==200){
									    $ctrl.showSimpleToast(response.data);
									    $ctrl.isDisabled = false;}
	                                else{
	                                    $ctrl.returned = "Something went wrong, try again later";
	                                    $ctrl.isDisabled = false;
	                                    }
	                                 });
	}

	$ctrl.submitSettings = function(){

//	    console.log($ctrl.settings);
	    AppApi.submitSettings({
	                            'new_ticket_notification': $ctrl.accountDetails.notification,
	                            'integration_id': $ctrl.integration_id,}).then(function(response){
									if(response.status==200){
									    $ctrl.showSimpleToast(response.data);
									    }
	                                else{
	                                    $ctrl.returned = "Something went wrong, try again later";

	                                    }
	                                 });
	}

    $ctrl.goBack = function(){
        $state.go('accountList')
    }

    $ctrl.newUrl = function(){
        AppApi.newUrl({'integration_id':$ctrl.integration_id})
            .then(function(result){
//                console.log(result)
                $ctrl.accountDetails.callback = result.data.callback;
            });
    }

    $ctrl.$onInit = function() {
        AppApi.accountDetails({'integration_id':$ctrl.integration_id})
        .then(function (result) {
            $ctrl.accountDetails = result.data;
//            console.log($ctrl.accountDetails);
        });
      }

	$ctrl.showConfirm = function(ev) {
    var confirm = $mdDialog.confirm()
          .title('Are you sure you want to delete this account?')
          .textContent('Deleting this account will erase all data asscosciated with it!')
          .ariaLabel('Delete Account')
          .targetEvent(ev)
          .ok("Delete")
          .cancel("Cancel");
    $mdDialog.show(confirm).then(function() {
      $ctrl.status = 'We are deleting your account. Please go to accounts page and refresh';
      console.log($ctrl.status);
      FreshdeskappApi.deleteAccount({
                    'integration_id': $ctrl.integration_id
      }).then(function(response){
            if(response.data.status){
                $ctrl.showSimpleToast(response.data.message);
                $state.go('accountList');
                }
            else{
                $ctrl.showSimpleToast(response.data.message);
            }
      });

    }, function() {
//        console.log('cancel')
      $ctrl.status = " ";
    });
  };


  $ctrl.showSimpleToast = function(data) {
    $mdToast.show(
                     $mdToast.simple()
                        .textContent(data)
                        .hideDelay(10000)
                  )};

}

//export function ButtonController()