export function AppController(AppApi, UserAccounts) {
  var $appctrl = this;
  $appctrl.userAccounts;
  console.log('main app')
//  FreshdeskappApi.listUserAccounts()
//    .then(function (result) {
//      UserAccounts.accountList = result.data;
//    });


//    console.log(UserAccounts.accountList);

//    $appctrl.$onInit = function() {
//        FreshdeskappApi.listUserAccounts()
//        .then(function (result) {
//            if (Array.isArray(result.data)){
//                UserAccounts.accountList = result.data;
//                console.log('1')
//                console.log(UserAccounts.accountList);
//            }
//            else{
//                UserAccounts.accountList = [];
//            }
//
//        });
//      }

}